package rcb;

public class Batsmen {
	void display() {
		System.out.println("KGF");
	}
//	public static void main(String[] args) {
		

	}
	

