package rcb;
import rcb.*;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Batsmen obj =new Batsmen();
obj.display();
	}

}
