package ipl;
import rcb.*;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Batsmen obj =new Batsmen();
		//System.out.println(display());
	//display();
		System.out.println("jjjj");
	}
	

}
