package com.si.day1;

//import com.tnsif.day1.Approach1;

class March6 {
//private int a=10;
//public static int b=8;

public static void main(String[] args) {
	//Approach1 a1 = new Approach1();
	System.out.println(March5.b);
	
	

}
 }
