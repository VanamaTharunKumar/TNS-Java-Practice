package com.si.day1;

public class March5 {
int a=10;
static int b=15;
int add(int c,int d) {
	return c+d;
}
static int mul(int c,int d) {
	return c*d;
}
	

}
/*We access the instance,static variables and methods from normal class(March5)*/