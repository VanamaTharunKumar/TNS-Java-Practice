package com.si.day1;

public class March51 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
March5 obj=new March5();
System.out.println(obj.a);
System.out.println(March5.b);
System.out.println(obj.add(8, 7));
System.out.println(March5.mul(8, 7));
	}

}
/*We access the instance,static variables and methods from normal class(March5)*/